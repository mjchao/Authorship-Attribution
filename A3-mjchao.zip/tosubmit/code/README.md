Run the program as follows:

python mycode.py <AAAC directory>

e.g.

python mycode.py AAAC_problems/problemA/